/*Package: package12*/
/*** HELP START ***//*
Package: package12
*//*** HELP END ***/
%macro package12(m);
%put &sysmacroname. &m.;
%mend package12;
