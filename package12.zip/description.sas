Type: Package
Package: package12
Title: Test package12
Version: 1.0.12
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'SQLinDS()'
DESCRIPTION START:
Package: package12
Title: Test package12
Version: 1.0.12
DESCRIPTION END:
