/*Package: package4*/
/*** HELP START ***//*
Package: package4
*//*** HELP END ***/
%macro package4(m);
%put &sysmacroname. &m.;
%package11(1.0.11)
%package12(1.0.12)
%package13(1.0.13)
%mend package4;
