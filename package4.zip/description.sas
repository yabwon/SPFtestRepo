Type: Package
Package: package4
Title: Test package4
Version: 1.0.4
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'package11(1.0.11)','package12(1.0.12)','package13(1.0.13)','SQLinDS()'
DESCRIPTION START:
Package: package4
Title: Test package4
Version: 1.0.4
DESCRIPTION END:
