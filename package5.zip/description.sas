Type: Package
Package: package5
Title: Test package5
Version: 1.0.5
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'package14(1.0.14)','package15(1.0.15)','SQLinDS()'
DESCRIPTION START:
Package: package5
Title: Test package5
Version: 1.0.5
DESCRIPTION END:
