/*Package: package5*/
/*** HELP START ***//*
Package: package5
*//*** HELP END ***/
%macro package5(m);
%put &sysmacroname. &m.;
%package14(1.0.14)
%package15(1.0.15)
%mend package5;
