/*Package: package3*/
/*** HELP START ***//*
Package: package3
*//*** HELP END ***/
%macro package3(m);
%put &sysmacroname. &m.;
%package8(1.0.8)
%package9(1.0.9)
%package10(1.0.10)
%mend package3;
