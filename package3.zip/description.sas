Type: Package
Package: package3
Title: Test package3
Version: 1.0.3
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'package8(1.0.8)','package9(1.0.9)','package10(1.0.10)','SQLinDS()'
DESCRIPTION START:
Package: package3
Title: Test package3
Version: 1.0.3
DESCRIPTION END:
