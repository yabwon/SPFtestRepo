/*Package: package9*/
/*** HELP START ***//*
Package: package9
*//*** HELP END ***/
%macro package9(m);
%put &sysmacroname. &m.;
%mend package9;
