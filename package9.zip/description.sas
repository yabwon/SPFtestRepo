Type: Package
Package: package9
Title: Test package9
Version: 1.0.9
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'SQLinDS()'
DESCRIPTION START:
Package: package9
Title: Test package9
Version: 1.0.9
DESCRIPTION END:
