/*Package: package2*/
/*** HELP START ***//*
Package: package2
*//*** HELP END ***/
%macro package2(m);
%put &sysmacroname. &m.;
%package5(1.0.5)
%package6(1.0.6)
%package7(1.0.7)
%mend package2;
