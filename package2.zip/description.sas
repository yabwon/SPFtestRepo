Type: Package
Package: package2
Title: Test package2
Version: 1.0.2
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'package5(1.0.5)','package6(1.0.6)','package7(1.0.7)','SQLinDS()'
DESCRIPTION START:
Package: package2
Title: Test package2
Version: 1.0.2
DESCRIPTION END:
