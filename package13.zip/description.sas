Type: Package
Package: package13
Title: Test package13
Version: 1.0.13
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'SQLinDS()'
DESCRIPTION START:
Package: package13
Title: Test package13
Version: 1.0.13
DESCRIPTION END:
