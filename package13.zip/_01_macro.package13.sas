/*Package: package13*/
/*** HELP START ***//*
Package: package13
*//*** HELP END ***/
%macro package13(m);
%put &sysmacroname. &m.;
%mend package13;
