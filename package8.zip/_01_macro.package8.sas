/*Package: package8*/
/*** HELP START ***//*
Package: package8
*//*** HELP END ***/
%macro package8(m);
%put &sysmacroname. &m.;
%mend package8;
