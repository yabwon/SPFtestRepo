Type: Package
Package: package8
Title: Test package8
Version: 1.0.8
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'SQLinDS()'
DESCRIPTION START:
Package: package8
Title: Test package8
Version: 1.0.8
DESCRIPTION END:
