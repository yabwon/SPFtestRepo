/*Package: package14*/
/*** HELP START ***//*
Package: package14
*//*** HELP END ***/
%macro package14(m);
%put &sysmacroname. &m.;
%mend package14;
