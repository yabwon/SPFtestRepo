Type: Package
Package: package14
Title: Test package14
Version: 1.0.14
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'SQLinDS()'
DESCRIPTION START:
Package: package14
Title: Test package14
Version: 1.0.14
DESCRIPTION END:
