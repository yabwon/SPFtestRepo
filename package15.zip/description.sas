Type: Package
Package: package15
Title: Test package15
Version: 1.0.15
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'SQLinDS()'
DESCRIPTION START:
Package: package15
Title: Test package15
Version: 1.0.15
DESCRIPTION END:
