/*Package: package15*/
/*** HELP START ***//*
Package: package15
*//*** HELP END ***/
%macro package15(m);
%put &sysmacroname. &m.;
%mend package15;
