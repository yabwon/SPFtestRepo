/*Package: package6*/
/*** HELP START ***//*
Package: package6
*//*** HELP END ***/
%macro package6(m);
%put &sysmacroname. &m.;
%mend package6;
