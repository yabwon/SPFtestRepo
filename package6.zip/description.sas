Type: Package
Package: package6
Title: Test package6
Version: 1.0.6
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'SQLinDS()'
DESCRIPTION START:
Package: package6
Title: Test package6
Version: 1.0.6
DESCRIPTION END:
