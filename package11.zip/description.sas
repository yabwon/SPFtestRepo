Type: Package
Package: package11
Title: Test package11
Version: 1.0.11
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'SQLinDS()'
DESCRIPTION START:
Package: package11
Title: Test package11
Version: 1.0.11
DESCRIPTION END:
