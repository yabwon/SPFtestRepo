/*Package: package10*/
/*** HELP START ***//*
Package: package10
*//*** HELP END ***/
%macro package10(m);
%put &sysmacroname. &m.;
%mend package10;
