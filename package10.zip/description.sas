Type: Package
Package: package10
Title: Test package10
Version: 1.0.10
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'SQLinDS()'
DESCRIPTION START:
Package: package10
Title: Test package10
Version: 1.0.10
DESCRIPTION END:
