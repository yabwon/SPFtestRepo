Type: Package
Package: package1
Title: Test package1
Version: 1.0.1
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'package2(1.0.2)','package3(1.0.3)','package4(1.0.4)','SQLinDS()'
DESCRIPTION START:
Package: package1
Title: Test package1
Version: 1.0.1
DESCRIPTION END:
