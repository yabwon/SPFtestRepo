filename PDE52C12 list;

 %put NOTE- ;
 %put NOTE: Loading package package1, version 1.0.1, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-06-02T15:22:56; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(package1) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  PDE52C12(packagemetadata.sas) / nosource2; 

 data _null_;                                                     
  call symputX("packageRequiredErrors", 0, "L");                  
 run;                                                             
%let temp_noNotes_etc=%sysfunc(getoption(NOTES));
options noNotes;
data _null_ ;                                                                                 
 if "*" NE symget("cherryPick") then do; put "INFO: No required packages loading."; stop; end; 
  length req name $ 64 vers verR $ 24 versN verRN 8 SYSloadedPackages $ 32767;                
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then             
    do;                                                                                       
      do until(EOF);                                                                          
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;      
        substr(SYSloadedPackages, 1+offset, 200) = value;                                     
      end;                                                                                    
    end;                                                                                      
  SYSloadedPackages = lowcase(SYSloadedPackages);                                             
  declare hash LP();                                                                          
  LP.defineKey("name");                                                                       
  LP.defineData("vers");                                                                      
  LP.defineDone();                                                                            
  do _N_ = 1 to countw(SYSloadedPackages);                                                    
    req = kscanx(SYSloadedPackages, _N_, " ");                                                
    name = lowcase(strip(kscanx(req, 1, "(")));                                               
    vers = compress(kscanx(req,-1, "("), ".", "KD");                                          
    _RC_ = LP.add();                                                                          
  end;                                                                                        
       LoadPackageExist = input(resolve('%SYSMACEXIST(   loadPackage)'), best.);            
    ICELoadPackageExist = input(resolve('%SYSMACEXIST(ICEloadPackage)'), best.);            
  do req = 
'package2(1.0.2)','package3(1.0.3)','package4(1.0.4)','sqlinds()'
 ;                                                       
    name = lowcase(strip(kscanx(req, 1, "(")));                                               
    verR = compress(kscanx(req,-1, "("), ".", "KD"); vers = "";                               
    LP_find = LP.find();                                                                      
    array V verR vers ;                                                                       
    array VN verRN versN;                                                                     
    do over V;                                                                                
      VN = input("0"!!scan(V,1,".","M"),?? best.)*1e8                                         
         + input("0"!!scan(V,2,".","M"),?? best.)*1e4                                         
         + input("0"!!scan(V,3,".","M"),?? best.)*1e0;                                        
    end;                                                                                      
    if (LP_find ne 0) or (LP_find = 0 and . < versN < verRN) then                                     
     do;                                                                                              
      put "INFO: Trying to load required SAS package: " req;                                          
       if LoadPackageExist then                                                                       
         call execute(cats('%nrstr(%loadPackage(', name, ", requiredVersion = ", verR, "))"));      
       else if ICELoadPackageExist then                                                               
         call execute(cats('%nrstr(%ICEloadPackage(', name, ", requiredVersion = ", verR, "))"));   
     end ;                                                                                            
  end ;                                                                                               
 stop;                                                                                        
run;                                                                                          
data _null_ ;                                                                                 
 if "*" NE symget("cherryPick") then do; put "INFO: No required packages checking."; stop; end; 
  length req name $ 64 vers verR $ 24 versN verRN 8 SYSloadedPackages $ 32767;                
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then             
    do;                                                                                       
      do until(EOF);                                                                          
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;      
        substr(SYSloadedPackages, 1+offset, 200) = value;                                     
      end;                                                                                    
      SYSloadedPackages = lowcase(SYSloadedPackages);                                         
      declare hash LP();                                                                      
      LP.defineKey("name");                                                                   
      LP.defineData("vers");                                                                  
      LP.defineDone();                                                                        
      do _N_ = 1 to countw(SYSloadedPackages);                                                
        req = kscanx(SYSloadedPackages, _N_, " ");                                            
        name = lowcase(strip(kscanx(req, 1, "(")));                                           
        vers = compress(kscanx(req,-1, "("), ".", "KD");                                      
        _RC_ = LP.add();                                                                      
      end;                                                                                    
      missingPackagr = 0;                                                                     
      do req = 
'package2(1.0.2)','package3(1.0.3)','package4(1.0.4)','sqlinds()'
 ;                                                   
        name = lowcase(strip(kscanx(req, 1, "(")));                                           
        verR = compress(kscanx(req,-1, "("), ".", "KD"); vers = " ";                          
        LP_find = LP.find();                                                                  
    array V verR vers ;                                                                       
    array VN verRN versN;                                                                     
    do over V;                                                                                
      VN = input("0"!!scan(V,1,".","M"),?? best.)*1e8                                         
         + input("0"!!scan(V,2,".","M"),?? best.)*1e4                                         
         + input("0"!!scan(V,3,".","M"),?? best.)*1e0;                                        
    end;                                                                                      
        if (LP_find ne 0) or (LP_find = 0 and . < versN < verRN) then                         
         do;                                                                                  
          missingPackagr = 1;                                                                 
          put "ERROR: SAS package: " req "is missing! Download it by hand or if the SAS session";       
          put "ERROR- has access to the Internet and the package is available at SASPAC repository";    
          put 'ERROR- use %installPackage(' name +(-1) "(" verR +(-1) ")) to install it."/;           
          put 'ERROR- Use %loadPackage(' name +(-1) ", requiredVersion=" verR +(-1) ") to load it."/; 
         end ;                                                                                
      end ;                                                                                   
      if missingPackagr then call symputX("packageRequiredErrors", 1, "L");                   
    end;                                                                                      
  else                                                                                        
    do;                                                                                       
      put "ERROR: No package loaded!";                                                        
      call symputX("packageRequiredErrors", 1, "L");                                          
      do req = 
'package2(1.0.2)','package3(1.0.3)','package4(1.0.4)','sqlinds()'
 ;                                                   
        name = lowcase(strip(kscanx(req, 1, "(")));                                           
        vers = compress(kscanx(req,-1, "("), ".", "KD");                                      
        put "ERROR: SAS package " req "is missing! Download it by hand or if the SAS session";       
        put "ERROR- has access to the Internet and the package is available at SASPAC repository";   
        put 'ERROR- use %installPackage(' name +(-1) "(" vers +(-1) ")) to install it."/;          
        put 'ERROR- Use %loadPackage(' name +(-1)", requiredVersion=" vers +(-1) ") to load it."/; 
      end ;                                                                                   
    end;                                                                                      
  stop;                                                                                       
run;                                                                                          
options &temp_noNotes_etc.;
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_;                                                     
  if 1 = symgetn("packageRequiredErrors") then                    
    do;                                                           
      put "ERROR: Loading package &packageName. will be aborted!";
      put "ERROR- Required components are missing.";              
      put "ERROR- *** STOP ***";                                  
      call symputX("packageRequiredErrors",
     'options ls = &ls_tmp. ps = &ps_tmp. 
       &notes_tmp. &source_tmp. msglevel=&msglevel_tmp. 
       &stimer_tmp. &fullstimer_tmp. ;
       data _null_;abort;run;', "L");              
    end;                                            
  else                                              
    call symputX("packageRequiredErrors", " ", "L");
 run;                                               
 &packageRequiredErrors.                            
 options &temp_noNotes_etc.;                        
 
%if (%str(*)=%superq(cherryPick)) or (package1 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "package1.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(package1)=1, NOTE# Macro package1 exist. It will be overwritten by the macro from the package1 package, ));
  %include PDE52C12(_01_macro.package1.sas) / nosource2;
%end; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;                                   
length CASLUDF $ 32767;                        
dtCASLudf = datetime();                        
CASLUDF =                                      
    '%macro package1CASLudf('         
 !! "list=1,depList="                          
 !! " package2  " 
 !! " package3  " 
 !! " package4  " 
 !! " sqlinds  " 
 !! ')/ des = ''CASL User Defined Functions loader for package1 package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `package1CASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `package2 package3 package4 sqlinds`.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20260602.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                           
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'
 !! "  filename PDE52C12 &ZIP. '&path./package1.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename PDE52C12 clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

data _null_;
run;
data _null_;
run;
%if (%str(*)=%superq(cherryPick)) %then %do;
proc fcmp outlib = work.package1fcmp.packagemeta ; 
 function package1META(meta $) $ 32767;
  m = char(upcase(meta),1);
   if m = 'V' then return(strip("1.0.1"));
   if m = 'D' then return(strip("2026-06-02T15:22:56"));
   if m = 'A' then return(strip("BJ"));
   if m = 'M' then return(strip("BJ"));
   if m = 'T' then return(strip("Test package1"));
   if m = 'E' then return(strip("UTF8"));
   if m = 'L' then return(strip("2026-06-02T15:22:56"));
   if m = 'P' then return(strip("'package2(1.0.2)','package3(1.0.3)','package4(1.0.4)','sqlinds()'"));
  return(" ");
 endfunc;
quit;
%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.package1fcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.package1fcmp);)
))
%macro package1META(meta)/parmbuff;
%if %superq(meta) = %then %return;
%do;%qsysfunc(strip(%qsysfunc(package1META&syspbuff.)))%end;
%mend;


%end;
%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

%if (%str(*)=%superq(cherryPick)) %then %do; 
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#package1(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'package1(1.0.1)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'package1(1.0.1)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'package1(1.0.1)', 'G');                            
      put / 'INFO: [SYSLOADEDPACKAGES] package1(1.0.1)';                                     
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
 options &temp_noNotes_etc.;
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package package1, version 1.0.1, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

