filename PDE52C12 list;
%put NOTE: Unloading package package1, version 1.0.1, license MIT;
%put NOTE- *** START ***;
proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'PACKAGE1META'
   ,'PACKAGE1IML'
   ,'PACKAGE1CASLUDF'
   %put NOTE- Element of type macro generated from the file "package1.sas" will be deleted;
   %put NOTE- ;
   ,"PACKAGE1                                                        "
  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"
  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'PACKAGE1FORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc fcmp outlib = work.package1fcmp.package;
quit;

proc fcmp outlib = work.package1fcmp.packagemeta;
deletefunc package1META;
quit;

options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.package1fcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%put; %put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));
proc SQL noprint;
quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

run;

data _null_ ;                                                                              
  length req name $ 64;                                                                    
  put "NOTE-" / "NOTE: To unload additional required SAS packages execute: " / "NOTE-";    
  do req = 
'package2(1.0.2)','package3(1.0.3)','package4(1.0.4)','sqlinds()'
 ;                                                    
    name = strip(kscanx(req, 1, "("));                                                     
    put '      %unloadPackage( ' name ")" ;                                              
  end ;                                                                                    
 put "NOTE-" / "NOTE-"; stop;                                                              
run;                                                                                       
data _null_ ;                                                                                         
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#package1(1.0.1)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#package1(1.0.1)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  
%put NOTE: Unloading package package1, version 1.0.1, license MIT;
%put NOTE- *** END ***;
%put NOTE- ;
/* unload.sas end */
