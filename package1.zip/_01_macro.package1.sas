/*Package: package1*/
/*** HELP START ***//*
Package: package1
*//*** HELP END ***/
%macro package1(m);
%put &sysmacroname. &m.;
%package2(1.0.2)
%package3(1.0.3)
%package4(1.0.4)
%mend package1;
