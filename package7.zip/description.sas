Type: Package
Package: package7
Title: Test package7
Version: 1.0.7
Author: BJ
Maintainer: BJ
License: MIT
Encoding: UTF8
ReqPackages: 'SQLinDS()'
DESCRIPTION START:
Package: package7
Title: Test package7
Version: 1.0.7
DESCRIPTION END:
