/*Package: package7*/
/*** HELP START ***//*
Package: package7
*//*** HELP END ***/
%macro package7(m);
%put &sysmacroname. &m.;
%mend package7;
